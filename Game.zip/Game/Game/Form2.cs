﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Media;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Game
{
    public partial class Form2 : Form
    {
        List<PictureBox> bullets = new List<PictureBox>();
        List<PictureBox> bulletsEnemy = new List<PictureBox>();

        Random r;
        SoundPlayer s;
        int seconds = 10; //Your time left
        int Score = 0; 
        int hitCount = 5; //It will show a "hit" for 5 seconds
        int count = 0; //How many times enemy has been hit
        int Health = 3; //Your health points
        int EnemiesKilled = 0;


        public Form2()
        {
            InitializeComponent();
            this.BackgroundImageLayout = ImageLayout.Stretch;          
        }

        private void timer1_Tick(object sender, EventArgs e)  //Checks if any bullet landed on you or your enemy
        {
            label4.Text = "Lives: " + Health;
            label2.Text = "Score: " + Score;
            label5.Text = "Enemies killed: " + EnemiesKilled;
            foreach (PictureBox p in bullets)
            {
                p.Location = new Point(p.Location.X, p.Location.Y - 40);
                if ((p.Location.X >= pictureBox2.Location.X - 40) && (p.Location.X <= pictureBox2.Location.X + 40) && (p.Location.Y < pictureBox2.Location.Y + 50) && (p.Location.Y > pictureBox2.Location.Y + 5))
                {

                    p.Dispose();                                                                                             
                    count++;
                    //Hit refresh
                    label3.Text = "Hit!";
                    timer4.Start();
                    hitCount = 5;
                    //
                    Score += 50;
                    if (count % 2 == 0)
                    {
                        label5.Text = "Enemies killed: " + EnemiesKilled++;
                        Score += 100;
                        pictureBox2.Location = new Point(r.Next(Width - pictureBox2.Width), pictureBox2.Location.Y); //"Loading" new enemy
                    }                   
                }

            }
            foreach (PictureBox p in bulletsEnemy)
            {
                p.Location = new Point(p.Location.X, p.Location.Y + 40);
                if ((p.Location.X >= pictureBox1.Location.X - 40) && (p.Location.X <= pictureBox1.Location.X + 40) && (p.Location.Y > pictureBox1.Location.Y - 50) && (p.Location.Y < pictureBox1.Location.Y - 5))
                {
                    p.Dispose();
                    Health--;
                    if (Score >=50)
                    {
                        Score -= 50;
                    }
                    label4.Text = "Lives: " + Health;
                    if (Health == 0)
                    {
                        pictureBox1.Dispose();
                        timer1.Stop();
                        timer2.Stop();
                        timer3.Stop();
                        timer4.Stop();
                        timer5.Stop();
                        saveScore(Score);
                        this.Close();
                    }
                }
            }                    
        }

        
        private void Form2_Load(object sender, EventArgs e)
        {
            pictureBox1.ImageLocation = "spaceship.png";
            r = new Random();
            s = new SoundPlayer("invaderkilled.wav");
        }

        private void Form2_KeyDown(object sender, KeyEventArgs e) 
        {
            if (e.KeyCode.ToString().Equals("Left"))
            {
                pictureBox1.Location = new Point(pictureBox1.Location.X - 30, pictureBox1.Location.Y);
            }
            else if (e.KeyCode.ToString().Equals("Right"))
            {
                pictureBox1.Location = new Point(pictureBox1.Location.X + 30, pictureBox1.Location.Y);
            }
            else if (e.KeyCode.ToString().Equals("Up"))
            {
                pictureBox1.Location = new Point(pictureBox1.Location.X, pictureBox1.Location.Y - 15);
            }
            else if (e.KeyCode.ToString().Equals("Down"))
            {
                pictureBox1.Location = new Point(pictureBox1.Location.X, pictureBox1.Location.Y + 15);
            }
            else if (e.KeyCode.ToString().Equals("Space"))
            {
                createBullet(pictureBox1.Location.X);
            }
        }

        private void createBullet(int startX)
        {
            PictureBox p = new PictureBox();
            p.ImageLocation = "bullet_icon.png";
            p.Location = new Point(startX + 5, pictureBox1.Location.Y - 50);
            p.Size = new Size(60, 50);
            p.SizeMode = PictureBoxSizeMode.StretchImage;
            Controls.Add(p);
            bullets.Add(p);
            s.Play();
        }

        private void createBulletEnemy(int x)
        {
            PictureBox p = new PictureBox();
            p.ImageLocation = "bullet_icon2.png";
            p.Location = new Point(x + 5, pictureBox2.Location.Y + 50);
            p.Size = new Size(60, 50);
            p.SizeMode = PictureBoxSizeMode.StretchImage;
            Controls.Add(p);
            bulletsEnemy.Add(p);
            s.Play();
        }

        private void timer2_Tick(object sender, EventArgs e) //Enemy moves and attacks
        {
            pictureBox2.Location = new Point(r.Next(Width - pictureBox2.Width), pictureBox2.Location.Y); //Apotiximeni prospatheia gia extra antipalous
            createBulletEnemy(pictureBox2.Location.X); //<-Den to evala se ksexoristo timer epeidh skeftika oti me auton ton tropo o antipalos tha einai pio aprovleptos


            //foreach (PictureBox enemy in newEnemies)
            //{
            //enemy.Location = new Point(r.Next(Width - enemy.Width), enemy.Location.Y);
            //createBulletEnemey(enemy.Location.X);
            //foreach (PictureBox bullet in bulletsEnemy)
            //{
            //    bullet.Location = new Point(bullet.Location.X, bullet.Location.Y + 40);
            //    if ((bullet.Location.X >= pictureBox1.Location.X - 40) && (bullet.Location.X <= pictureBox1.Location.X + 40) && (bullet.Location.Y > pictureBox1.Location.Y - 50) && (bullet.Location.Y < pictureBox1.Location.Y - 5))
            //    {
            //        bullet.Dispose();
            //        Health--;
            //        label4.Text = "Lives: " + Health;
            //        if (Health == 0)
            //        {
            //            this.Close();
            //        }
            //    }
            //}////KALO
            //foreach (PictureBox bullet in bullets)
            //{
            //    bullet.Location = new Point(bullet.Location.X, bullet.Location.Y - 40);
            //    if ((bullet.Location.X >= enemy.Location.X - 40) && (bullet.Location.X <= enemy.Location.X + 40) )//&& (bullet.Location.Y < enemy.Location.Y + 50) && (bullet.Location.Y > enemy.Location.Y + 5))
            //    {
            //        bullet.Dispose();
            //        newEnemiesHP[j]--;
            //        count++;
            //        //Hit refresh
            //        label3.Text = "Hit!";
            //        timer4.Start();
            //        hitCount = 4;
            //        //
            //        Score += 50;
            //        if (newEnemiesHP[j] == 0)
            //        {
            //          label5.Text = "Enemies killed: " + EnemiesKilled++;
            //          Score += 100;
            //            foreach(PictureBox p in newEnemies)
            //            {
            //                p.Location = new Point(r.Next(Width - p.Width), p.Location.Y);
            //            }
            //        }
            //        j++;
            //        //if (count % 2 == 0)
            //        //{
            //        //    label5.Text = "Enemies killed: " + EnemiesKilled++;
            //        //    loadEnemies(EnemiesKilled, pictureBox2.Width);
            //        //    Score += 100;
            //        //    pictureBox2.Location = new Point(r.Next(Width - pictureBox2.Width), pictureBox2.Location.Y);
            //        //}
            //    }

            //}              
            //}        
        }

        private void timer3_Tick(object sender, EventArgs e) //Time left
        {
            label1.Text = "Time left: " + seconds.ToString();
            if (seconds == 0)
            {
                timer1.Stop();
                timer2.Stop();
                saveScore(Score);
                this.Close();
            }
            seconds--;  
        }

        private void timer4_Tick(object sender, EventArgs e) //Refreshes "hit"!
        {
            if (hitCount == 0)
            {
                label3.Text = "";
            }
            hitCount--;
        }

        //private void loadEnemies(int EnemiesKilled, int x)
        //{
        //    //label6.Text = "asdasd-" + EnemiesKilled;
        //    if (EnemiesKilled > 0)
        //    {
        //        PictureBox p = new PictureBox();
        //        p.ImageLocation = "invader.png";
        //        p.Location = new Point(r.Next(Width - x), 11);
        //        p.Size = new Size(74, 96);
        //        p.SizeMode = PictureBoxSizeMode.Zoom;
        //        Controls.Add(p);
        //        newEnemies.Add(p);
        //        newEnemiesHP.Add(2);
        //    }
        //}

        private void timer5_Tick(object sender, EventArgs e) 
        {

        }

        public void saveScore(int x)
        {
            if (!File.Exists(".\\Leaderboard.txt")) 
            {
                File.Create(".\\Leaderboard.txt").Close();
            }
            
            File.AppendAllText(".\\Leaderboard.txt", x.ToString() + Environment.NewLine);
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e) //Game closed from X button
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
               timer1.Stop();
               timer2.Stop();
               timer3.Stop();
               timer4.Stop(); //Den theoro sosto na kano save edo to score epeidh einai san na "paratise" to paixnidi.
            }
        }
    }
 
}
