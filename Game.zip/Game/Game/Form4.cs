﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Game
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            List<int> Leaderboard = new List<int>();
            for (int i = 0; i < 10; i++)
            {
                Leaderboard.Add(0);
            }

            if (File.Exists(".\\Leaderboard.txt"))
            {
                string[] lines = File.ReadAllLines(".\\Leaderboard.txt");

                foreach (string line in lines)
                    Leaderboard.Add(int.Parse(line));

                Leaderboard.Sort();
                Leaderboard.Reverse();
                label2.Text = " " + Leaderboard[0];
                label3.Text = " " + Leaderboard[1];
                label4.Text = " " + Leaderboard[2];
                label5.Text = " " + Leaderboard[3];
                label6.Text = " " + Leaderboard[4];
                label7.Text = " " + Leaderboard[5];
                label8.Text = " " + Leaderboard[6];
                label9.Text = " " + Leaderboard[7];
                label10.Text = " " + Leaderboard[8];
                label11.Text = " " + Leaderboard[9];
            }
            else
            {
                label2.Text = " " + 0;
                label3.Text = " " + 0;
                label4.Text = " " + 0;
                label5.Text = " " + 0;
                label6.Text = " " + 0;
                label7.Text = " " + 0;
                label8.Text = " " + 0;
                label9.Text = " " + 0;
                label10.Text = " " + 0;
                label11.Text = " " + 0;
            }
        }
    }
}
